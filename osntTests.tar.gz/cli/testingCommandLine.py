#!/usr/bin/env python

import os
import numpy as np
import pandas as pd
import time


def parseOutput(outputFileName):

	f = open(outputFileName)
	print "in parser"

	flag = 0

	pktPerSecond = []
	bytePerSecond = []
	
	startPacketNumber = 0
	latestPacketNumber = 0
	for line in f:

		if 'Packet No' in line:
			if flag == 0 :
				print line
				line = line.replace(":","")
				line = line.split(" ")
				print line
				startPacketNumber =  int(line[5])
				latestPacketNumber =  int(line[5])

			if flag != 0 and flag% 4 == 0:
				
				line = line.replace(":","")
				line = line.split(" ")
				if line[5] != "":
					try:
						int(line[5])
					except:
						continue
					if latestPacketNumber<int(line[5]):
						latestPacketNumber =  int(line[5])
			
		if 'Byte/Sec' in line:
			if flag != 0 and flag% 4 == 0:
				
				
				line = line.replace(":","")
				line = line.split(" ")

				#print line

				prexifOfPktPerSecond = line[6][-1]
				speedOfPktPerSecond = line[6][0:len(line[6])-1]
			
				prexifOfBytePerSecond  = line[-1][-2]
				speedOfBytePerSecond = line[-1][0:len(line[-1])-2]
				
				if float(speedOfPktPerSecond) == 0 or  float(speedOfBytePerSecond) == 0:
					#pktPerSecond = np.append(pktPerSecond, 0)
					#bytePerSecond =np.append(bytePerSecond, 0)				
					continue 
				
				if prexifOfPktPerSecond == "G":
					speedOfPktPerSecond = float(speedOfPktPerSecond)*1000000000
				elif prexifOfPktPerSecond == "M":
					speedOfPktPerSecond = float(speedOfPktPerSecond)*1e6
				elif prexifOfPktPerSecond == "K":
					speedOfPktPerSecond = float(speedOfPktPerSecond)*1e3
				else:
				
					print "error with byte per second calc"
			
				if prexifOfBytePerSecond  == "G":
					speedOfBytePerSecond  = float(speedOfBytePerSecond )*1000000000
				elif prexifOfBytePerSecond  == "M":
					speedOfBytePerSecond  = float(speedOfBytePerSecond )*1e6
				elif prexifOfBytePerSecond  == "K":
					speedOfBytePerSecond  = float(speedOfBytePerSecond )*1e3
				else:
					print "error with byte per second calc"
				print speedOfPktPerSecond
			

			

				pktPerSecond = np.append(pktPerSecond, float(speedOfPktPerSecond))

				print speedOfBytePerSecond

				bytePerSecond =np.append(bytePerSecond, float(speedOfBytePerSecond))

		

			flag = flag +1
	f.close() 
	recieved = float(latestPacketNumber - startPacketNumber )
	dropping = 50000000 - recieved
	print "total number recieved"
	print recieved
	print "dropping"
	print dropping 
	print "percent loss" 
	percentageLoss = float(dropping /50000000)
	print percentageLoss

	if len(pktPerSecond) == 0 or len(bytePerSecond) == 0:
		return 0,0,recieved, dropping, percentageLoss
	else:
		return np.median(pktPerSecond),np.median(bytePerSecond),recieved, dropping, percentageLoss

medianOfPktPerSecond = []
medianfOfBytePerSecond = []
numberOfPktsRecieved = []
numberOfPktsDropped = []
percentageLoss = []
currentIterations = []

iteration = 0

l = [i*32 for i in range(47,48)]
l.extend([i for i in range(64,1518) if i%32!=0])

for x in l:
#for x in range(256,257):
	number = str(x)
	print number
	pcapFileName ="get_"+number+".cap"
	print pcapFileName	
	exists = os.path.isfile("/root/pcapOSNT/"+pcapFileName)


	delay = str(int(x/22))
	#delay = str(65)
	if exists:
	
		outputFileName =  "get_"+number+"_parse.txt"
		
		os.system("timeout -s SIGTERM "+ delay + " python osnt-tool-cmd.py -ifp0 /root/pcapOSNT/"+ pcapFileName +" -rpn0 50000000 -ipg0 0 -run -ds > "+ outputFileName)
		pktPerSecond, bytePerSecond, recieved, dropping, percentageLossValue = parseOutput(outputFileName)

		
		medianOfPktPerSecond = np.append(medianOfPktPerSecond, [pktPerSecond])
		medianfOfBytePerSecond = np.append(medianfOfBytePerSecond, [bytePerSecond])
		numberOfPktsRecieved = np.append(numberOfPktsRecieved, [recieved])
		numberOfPktsDropped = np.append(numberOfPktsDropped, [dropping])
		percentageLoss = np.append(percentageLoss, [percentageLossValue])
		currentIterations = np.append(currentIterations, [x])
		
	else:
		print "doesn't exist"
		medianOfPktPerSecond = np.append(medianOfPktPerSecond, 0)
		medianfOfBytePerSecond = np.append(medianfOfBytePerSecond,0)
		numberOfPktsRecieved = np.append(numberOfPktsRecieved , 0)
		numberOfPktsDropped = np.append(numberOfPktsDropped, 0)
		percentageLoss = np.append(percentageLoss , 0)
		currentIterations = np.append(currentIterations, [x])
		#continue
	
	#if iteration % 5 == 0 and iteration != 0:
	if x%2 == 0 : 
		df = pd.DataFrame(currentIterations)
		df['pktPerSecond'] = medianOfPktPerSecond
		df['bytePerSecond'] = medianfOfBytePerSecond
		df['noPktsRecieved'] = numberOfPktsRecieved
		df['noPktsDropped'] = numberOfPktsDropped
		df['percentageLoss'] = percentageLoss
		print df
		df.to_csv("testCsvV2.csv", header = False,mode = 'a')
		medianOfPktPerSecond = []
		medianfOfBytePerSecond = []
		numberOfPktsRecieved = []
		numberOfPktsDropped = []
		percentageLoss = []
		currentIterations = []
	
	print "sleeping"
	time.sleep(1)
	
	


#df = pd.DataFrame(medianOfPktPerSecond)
#df['bytePerSecond'] = medianfOfBytePerSecond
#print df
#df.to_csv("testCsv.csv")
#number = str(288)
#pcapFileName ="get_"+number+".cap"

#exists = os.path.isfile("/root/get_106.cap")
#print exists

#os.system("timeout 10 python osnt-tool-cmd.py -ifp0 ~/"+ pcapFileName +" -rpn0 100000000 -ipg0 96 -run -ds > testParseV2.txt")
#timeout 10 python osnt-tool-cmd.py -ifp0 ~/get_288.cap -rpn0 100000000 -ipg0 96 -run -ds > testParse.txt


