#!/usr/bin/env python

import numpy as np 

import pandas as pd
import os 
import glob

#for each pcap file we run a command

#for each file the above produces
f = open("testing.txt")
flag = 0
medianOfPktPerSecond = []
medianfOfBytePerSecond = []

pktPerSecond = []
bytePerSecond = []


for line in f:
	if 'Byte/Sec' in line:
		if flag == 0 or flag% 4 == 0:
			
			line = line.replace(":","")
			line = line.split(" ")
			prexifOfPktPerSecond = line[6][-1]
			speedOfPktPerSecond = line[6][0:len(line[6])-1]
			
			prexifOfBytePerSecond  = line[-1][-2]
			speedOfBytePerSecond = line[-1][0:len(line[-1])-2]
			
			if prexifOfPktPerSecond == "G":
				speedOfPktPerSecond = float(speedOfPktPerSecond)*1000000000
			elif prexifOfPktPerSecond == "M":
				speedOfPktPerSecond = float(speedOfPktPerSecond)*1e6
			elif prexifOfPktPerSecond == "K":
				speedOfPktPerSecond = float(speedOfPktPerSecond)*1e3
			else:
				print "error with byte per second calc"
			
			if prexifOfBytePerSecond  == "G":
				speedOfBytePerSecond  = float(speedOfBytePerSecond )*1000000000
			elif prexifOfBytePerSecond  == "M":
				speedOfBytePerSecond  = float(speedOfBytePerSecond )*1e6
			elif prexifOfBytePerSecond  == "K":
				speedOfBytePerSecond  = float(speedOfBytePerSecond )*1e3
			else:
				print "error with byte per second calc"
			print speedOfPktPerSecond
			

			if speedOfPktPerSecond == 0 or  speedOfBytePerSecond == 0:
				continue 
			
			pktPerSecond = np.append(pktPerSecond, speedOfPktPerSecond)

			print speedOfBytePerSecond

			bytePerSecond =np.append(bytePerSecond, speedOfBytePerSecond)
		flag = flag +1


print np.median(pktPerSecond)
print np.median(bytePerSecond)



medianOfPktPerSecond = np.append(medianOfPktPerSecond, np.median(pktPerSecond))
medianfOfBytePerSecond = np.append(medianfOfBytePerSecond, np.median(bytePerSecond))


#medianPktPerSecond = np.median(pktPerSecond)
#medianBytePerSecond = np.median(bytePerSecond)
#testTuple = np.array(medianPktPerSecond,medianBytePerSecond)
#print testTuple

#np.savetxt("test.txt",testTuple, delimiter = ",")

#df = pd.DataFrame(testTuple)
#print df




























