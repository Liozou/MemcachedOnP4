This is the synthetic testing environment.


Setup
- 103,nf0 to 104,nf0
-104,nf1 to 104,eth2
-produce pcap files hwTest.py ( forms part of the functional validation env) for multiple sizes
- within TestingCommandLine.py point the input directory, written on 
the OSNT command section, to point to the pcap files. It will iterate over them and 
get them when it executes OSNT from python. Note this will likely include changing the for loop
 



testingCommandLine.py 
- this runs a OSNT usinf the command line 
- iterates over the pcap files
-for each executes OSNT command which is piped in a .txt file
- parser uses this to get throughput and dropped packet statistics




the *.txt files in this folder are all the logs of OSNT running from testingCommandLine.py running.
the parser from testingCommandLine.py

